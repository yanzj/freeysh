See document "HowTo_ToolChain_STM32_Ubuntu.pdf" chapter "5.1.1 Librarys" available at:
http://www.seng.de/service-support/downloads/
for downloading and installing the libraries.

